import React, { useState } from 'react'; 
import { StyleSheet,View, Text, Switch } from 'react-native'; 
import { DataTable } from 'react-native-paper'; 

const Schedule = () => { 
	const [value, setValue] = useState(false)

	const onValueChange = value => {
	  setValue(value)
	}	
return ( 
	<DataTable style={styles.container}> 
	<DataTable.Header style={styles.tableHeader}> 
		<DataTable.Title>Description</DataTable.Title> 
		<DataTable.Title>Time Window</DataTable.Title> 
		<DataTable.Title>Frequency</DataTable.Title> 
		<DataTable.Title>Enable</DataTable.Title>
	</DataTable.Header> 
	<DataTable.Row> 
		<DataTable.Cell>Power yoga</DataTable.Cell> 
		<DataTable.Cell>6:30am to 7 am</DataTable.Cell> 
		<DataTable.Cell>1</DataTable.Cell> 
		<DataTable.Cell>
		<View style={styles.scontainer}>
					<View style={styles.switchContainer}>
					<Switch
						style={styles.switch}
						onValueChange={onValueChange}
						value={value}
					/>
					</View>
				</View>
		</DataTable.Cell>
	</DataTable.Row> 

	<DataTable.Row> 
	<DataTable.Cell>Power yoga</DataTable.Cell> 
		<DataTable.Cell>6:30am to 7 am</DataTable.Cell> 
		<DataTable.Cell>2</DataTable.Cell> 
		<DataTable.Cell>
				<View style={styles.scontainer}>
					<View style={styles.switchContainer}>
					<Switch
						style={styles.switch}
						onValueChange={onValueChange}
						value={value}
					/>
					</View>
				</View>
		</DataTable.Cell>
	</DataTable.Row> 
	<DataTable.Row> 
	<DataTable.Cell>Power yoga</DataTable.Cell> 
		<DataTable.Cell>6:30am to 7 am</DataTable.Cell> 
		<DataTable.Cell>3</DataTable.Cell> 
		<DataTable.Cell>
		<View style={styles.scontainer}>
					<View style={styles.switchContainer}>
					<Switch
						style={styles.switch}
						onValueChange={onValueChange}
						value={value}
					/>
					</View>
				</View>
		</DataTable.Cell>
	</DataTable.Row> 
	<DataTable.Row> 
	<DataTable.Cell>Power yoga</DataTable.Cell> 
		<DataTable.Cell>6:30am to 7 am</DataTable.Cell> 
		<DataTable.Cell>4</DataTable.Cell> 
		<DataTable.Cell>
		<View style={styles.scontainer}>
					<View style={styles.switchContainer}>
					<Switch
						style={styles.switch}
						onValueChange={onValueChange}
						value="Off"
					/>
					</View>
				</View>
		</DataTable.Cell> 
	</DataTable.Row> 
	</DataTable> 
); 
}; 

export default Schedule; 

const styles = StyleSheet.create({ 
container: { 
	padding: 15, 
}, 
tableHeader: { 
	backgroundColor: '#DCDCDC', 
}, 
scontainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center"
  },
  switchContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center"
  },
  switch: {
    marginLeft: 10
  }
});


