import React, { useState } from 'react';
import { StyleSheet, View, Switch, ScrollView, TextInput } from 'react-native';
import { DataTable, Button } from 'react-native-paper';

const Schedule = () => {
  // Define your initial state with dynamic data
  const [scheduleData, setScheduleData] = useState([
    { id: 1, description: 'Power yoga', timeWindow: '6:30am to 7 am', frequency: 1, isEnabled: false },
    { id: 2, description: 'Power yoga', timeWindow: '6:30am to 7 am', frequency: 2, isEnabled: false },
    { id: 3, description: 'Power yoga', timeWindow: '6:30am to 7 am', frequency: 3, isEnabled: false },
    { id: 4, description: 'Power yoga', timeWindow: '6:30am to 7 am', frequency: 4, isEnabled: false },
  ]);

  // State to manage form values for the new schedule row
  const [newSchedule, setNewSchedule] = useState({
    id: null,
    description: '',
    timeWindow: '',
    frequency: '',
    isEnabled: false,
  });

  // State to manage whether to show the new schedule form
  const [showNewScheduleForm, setShowNewScheduleForm] = useState(false);

  // Function to handle adding a new schedule
  const addNewSchedule = () => {
    const newId = scheduleData.length + 1; // Generate new id
    const updatedNewSchedule = { ...newSchedule, id: newId };
    setScheduleData([...scheduleData, updatedNewSchedule]); // Add new schedule to state
    setNewSchedule(prevSchedule => ({ // Preserve existing data in newSchedule
      ...prevSchedule,
      id: null,
      isEnabled: false,
    }));
  };

  // Handler for toggling the switch
  const toggleSwitch = (rowId) => {
    const updatedSchedule = scheduleData.map(row => {
      if (row.id === rowId) {
        return { ...row, isEnabled: !row.isEnabled };
      }
      return row;
    });
    setScheduleData(updatedSchedule);
  };

  // Handler for editing description
  const handleDescriptionChange = (text) => {
    setNewSchedule({ ...newSchedule, description: text });
  };

  // Handler for editing time window
  const handleTimeWindowChange = (text) => {
    setNewSchedule({ ...newSchedule, timeWindow: text });
  };

  // Handler for editing frequency
  const handleFrequencyChange = (text) => {
    setNewSchedule({ ...newSchedule, frequency: text });
  };

  return (
    <View style={styles.container}>
      {/* Button to toggle showing new schedule form */}
      <Button
        icon="plus"
        mode="contained"
        onPress={() => setShowNewScheduleForm(true)}
        style={styles.addButton}
      >
        Add Schedule
      </Button>

      {/* Schedule DataTable wrapped in ScrollView */}
      <ScrollView horizontal>
        <View style={styles.dataTableContainer}>
          <DataTable style={styles.dataTable}>
            <DataTable.Header style={styles.tableHeader}>
              <DataTable.Title style={styles.headerCell}>Description</DataTable.Title>
              <DataTable.Title style={styles.headerCell}>Time Window</DataTable.Title>
              <DataTable.Title style={styles.headerCell}>Frequency</DataTable.Title>
              <DataTable.Title style={styles.headerCell}>Enable</DataTable.Title>
            </DataTable.Header>

            {/* Render existing schedule data */}
            {scheduleData.map(row => (
              <DataTable.Row key={row.id} style={styles.tableRow}>
                <DataTable.Cell style={styles.cell}>
                  {row.description}
                </DataTable.Cell>
                <DataTable.Cell style={styles.cell}>
                  {row.timeWindow}
                </DataTable.Cell>
                <DataTable.Cell style={styles.cell}>
                  {row.frequency}
                </DataTable.Cell>
                <DataTable.Cell>
                  <View style={styles.switchContainer}>
                    <Switch
                      style={styles.switch}
                      onValueChange={() => toggleSwitch(row.id)}
                      value={row.isEnabled}
                    />
                  </View>
                </DataTable.Cell>
              </DataTable.Row>
            ))}

            {/* Conditionally render new schedule form */}
            {showNewScheduleForm && (
              <DataTable.Row key={newSchedule.id} style={styles.tableRow}>
                <DataTable.Cell style={styles.cell}>
                  <TextInput
                    style={styles.input}
                    onChangeText={handleDescriptionChange}
                    value={newSchedule.description}
                  />
                </DataTable.Cell>
                <DataTable.Cell style={styles.cell}>
                  <TextInput
                    style={styles.input}
                    onChangeText={handleTimeWindowChange}
                    value={newSchedule.timeWindow}
                  />
                </DataTable.Cell>
                <DataTable.Cell style={styles.cell}>
                  <TextInput
                    style={styles.input}
                    onChangeText={handleFrequencyChange}
                    value={newSchedule.frequency}
                    keyboardType="numeric"
                  />
                </DataTable.Cell>
                <DataTable.Cell>
                  <View style={styles.switchContainer}>
                    <Switch
                      style={styles.switch}
                      onValueChange={() => setNewSchedule({ ...newSchedule, isEnabled: !newSchedule.isEnabled })}
                      value={newSchedule.isEnabled}
                    />
                  </View>
                </DataTable.Cell>
              </DataTable.Row>
            )}
          </DataTable>
        </View>
      </ScrollView>
      
      {/* Button to add new schedule */}
      <Button
        mode="contained"
        onPress={addNewSchedule}
        style={styles.addButton}
      >
        Save
      </Button>
    </View>
  );
};

export default Schedule;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
  },
  dataTableContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    overflow: 'hidden', // Ensure borders are within the table container
  },
  dataTable: {
    flex: 1,
  },
  tableHeader: {
    backgroundColor: '#DCDCDC',
    flexDirection: 'row', // Ensure headers are aligned with rows
  },
  headerCell: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 10, // Adjust the spacing as needed
    paddingHorizontal: 5,
  },
  tableRow: {
    flexDirection: 'row', // Ensure rows are aligned with headers
  },
  cell: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 10, // Adjust the spacing as needed
    paddingHorizontal: 5,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  switch: {
    marginLeft: 10,
  },
  addButton: {
    alignSelf: 'flex-end',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 5,
  },
});
